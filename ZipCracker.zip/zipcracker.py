import pyfiglet
import zipfile
from termcolor import colored
r = pyfiglet.figlet_format("     ZipCracker     ", font="slant")
print(colored(r,'green',attrs=['bold']))
print(colored("          &&&&&&&&&&&&&&&&&  TECHNICAL B9T  &&&&&&&&&&&&&&&&&          ",'red'))
print("                                  ")
pwd_filename = input("[+] Enter passwordlist name : ")
zip_filename = input("[+] Enter zipfile name : ")
print(" ")
with open(pwd_filename, "rb") as passwords:
   
    passwords_list = passwords.readlines()
    
    total_passwords = len(passwords_list)

    my_zip_file = zipfile.ZipFile(zip_filename)
    
    for index, password in enumerate(passwords_list):
        try:
            my_zip_file.extractall(path="Extracted Folder",  pwd=password.strip())
        except:
           
            continue
      
        else:
            print(colored(("[+] Password Found: ",password.decode().strip()),'yellow'))
            exit(0)
            
    print(colored("[+] Password not found ,Try another passwordlist",'yellow'))